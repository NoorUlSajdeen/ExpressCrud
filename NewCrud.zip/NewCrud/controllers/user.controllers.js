const worker = require("../models/user-models");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Get all data
exports.getAlldata = async (req, res) => {
    try {
        const workers = await worker.find();
        res.render("view-user", {workers});
    } catch (error) {
        res.status(500).json({ error: "Failed to fetch data", details: error.message });
    }
};

// Add data
exports.addData = async (req, res) => {
    try {
        const { name, email, phone, password } = req.body;
        const user = await worker.create({ name, email, phone, password });
        if(user){
            res.status(201).json({
                msg: "Registration SuccessFully",
                token: await user.generateToken(),
                userId: user.uid.toString(),
            });
            res.redirect("/");
            // res.render("view-user", {user});
        }
    } catch (error) {
        res.status(500).json({ error: "Failed to add data", details: error.message });
    }
};

exports.addDatapage = async (req, res) => {
    res.render("add-user");
}

// Update data
exports.updateData = async (req, res) => {
    try {
        // const { id } = req.params;
        const { name, email, phone, password } = req.body;
        const updatedWorker = await worker.findByIdAndUpdate( req.params.id, { name, email, phone, password }, { new: true });
        if (!updatedWorker) return res.status(404).send("User not found");
        res.redirect("/");
    } catch (error) {
        res.status(500).send("Error updating user");
    }
};

exports.updateDatapage = async (req, res) => {
    try {
        const user = await worker.findById(req.params.id);
        res.render("update-user", { user });
    } catch (error) {
        res.status(500).send("Error fetching user details");
    }
};

// Delete data
exports.deleteData = async (req, res) => {
    try {
        const { id } = req.params;
        const deletedUser = await worker.findByIdAndDelete(id);
        if (!deletedUser) {
            return res.status(404).json({ error: "User not found" });
        }
        res.status(200).json({ message: "User deleted successfully" });
    } catch (error) {
        res.status(500).json({ error: "Error deleting user" });
    }
};
