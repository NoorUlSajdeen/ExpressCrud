const express = require("express");
const route = express.Router();
const empController = require("../controllers/user.controllers");

route.post("/add", empController.addData);
route.get("/", empController.getAlldata);
route.get("/add", empController.addDatapage);
route.post("/update/:id", empController.updateData);
route.get("/update/:id", empController.updateDatapage);
route.delete("/delete/:id", empController.deleteData);

module.exports = route;